const https = require('https');
const AWS = require('aws-sdk');

const bedrock = new AWS.BedrockRuntime({ region: 'us-east-1' });

// BigKinds API 호출
async function searchNews(query, accessKey) {
  const today = new Date();
  const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
  
  const requestBody = {
    access_key: accessKey,
    argument: {
      query: query,
      published_at: {
        from: weekAgo.toISOString().split('T')[0],
        until: today.toISOString().split('T')[0]
      },
      category: ["경제"],
      sort: { date: "desc" },
      hilight: 200,
      return_from: 0,
      return_size: 3,
      fields: ["title", "content", "published_at", "provider", "hilight", "provider_link_page"]
    }
  };

  return new Promise((resolve, reject) => {
    const data = JSON.stringify(requestBody);
    
    const options = {
      hostname: 'tools.kinds.or.kr',
      path: '/search/news',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        try {
          const result = JSON.parse(body);
          if (result.result === 0) {
            resolve(result.return_object.documents);
          } else {
            reject(new Error('BigKinds API error'));
          }
        } catch (error) {
          reject(error);
        }
      });
    });

    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// AI 응답 생성 (AWS Bedrock Claude)
async function generateResponse(userMessage, newsData) {
  const newsContext = newsData.map(news => 
    `제목: ${news.title}\n언론사: ${news.provider}\n발행일: ${news.published_at}\n내용: ${news.hilight || news.content.substring(0, 200)}`
  ).join('\n\n');

  const prompt = `당신은 경제 뉴스 전문 AI 어시스턴트입니다. 사용자의 질문에 대해 최신 뉴스 정보를 바탕으로 정확하고 유용한 답변을 제공하세요.

사용자 질문: ${userMessage}

관련 뉴스:
${newsContext}

위 뉴스 정보를 참고하여 사용자 질문에 대한 답변을 작성해주세요. 답변은 한국어로, 친근하고 이해하기 쉽게 작성해주세요.`;

  const requestBody = {
    anthropic_version: "bedrock-2023-05-31",
    max_tokens: 500,
    messages: [
      {
        role: "user",
        content: prompt
      }
    ]
  };

  try {
    const response = await bedrock.invokeModel({
      modelId: 'anthropic.claude-3-sonnet-20240229-v1:0',
      contentType: 'application/json',
      accept: 'application/json',
      body: JSON.stringify(requestBody)
    }).promise();

    const responseBody = JSON.parse(response.body.toString());
    return responseBody.content[0].text;
  } catch (error) {
    throw new Error(`Bedrock API error: ${error.message}`);
  }
}

exports.handler = async (event) => {
  try {
    const { message, conversationId } = JSON.parse(event.body);
    
    const bigkindsKey = process.env.BIGKINDS_API_KEY;
    
    if (!bigkindsKey) {
      return {
        statusCode: 500,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'BigKinds API key not configured' })
      };
    }

    // 뉴스 검색
    const newsData = await searchNews(message, bigkindsKey);
    
    // AI 응답 생성
    const aiResponse = await generateResponse(message, newsData);
    
    // 소스 정보 구성
    const sources = newsData.map(news => ({
      title: news.title,
      provider: news.provider,
      published_at: news.published_at,
      url: news.provider_link_page
    }));

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        response: aiResponse,
        conversationId: conversationId,
        sources: sources
      })
    };

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};